<?php
$claveUsuario1 = "manizales2026";
$claveUsuario2 = "manizales2026";

echo "Usuario 1: laura_gomez, clave: $claveUsuario1 <br>";
echo "Usuario 2: andres_rios, clave: $claveUsuario2 <br><br>";

echo "=== SIN SAL ===<br>";
echo "Hash Usuario 1: " . hash('sha256', $claveUsuario1) . "<br>";
echo "Hash Usuario 2: " . hash('sha256', $claveUsuario2) . "<br>";
echo "¿Son idénticos? " . (hash('sha256', $claveUsuario1) === hash('sha256', $claveUsuario2) ? "SÍ" : "NO") . "<br><br>";

echo "=== CON SAL ÚNICA POR USUARIO ===<br>";
$sal1 = bin2hex(random_bytes(16));
$sal2 = bin2hex(random_bytes(16));

$inicio = hrtime(true);
$hashConSal1 = hash('sha256', $sal1 . $claveUsuario1);
$tiempoSha = (hrtime(true) - $inicio) / 1000;
$hashConSal2 = hash('sha256', $sal2 . $claveUsuario2);

echo "Sal Usuario 1: $sal1 <br>";
echo "Hash Usuario 1 (con sal): $hashConSal1 <br><br>";
echo "Sal Usuario 2: $sal2 <br>";
echo "Hash Usuario 2 (con sal): $hashConSal2 <br>";
echo "¿Son idénticos? " . ($hashConSal1 === $hashConSal2 ? "SÍ" : "NO") . "<br><br>";

echo "=== COMPROBAR EL LOGIN CON LA SAL GUARDADA ===<br>";
$escrita = "manizales2026";
echo "laura_gomez escribe $escrita: " . (hash('sha256', $sal1 . $escrita) === $hashConSal1 ? "clave correcta" : "clave incorrecta") . "<br>";
$escrita = "manizales2025";
echo "laura_gomez escribe $escrita: " . (hash('sha256', $sal1 . $escrita) === $hashConSal1 ? "clave correcta" : "clave incorrecta") . "<br><br>";

echo "=== CON PASSWORD_HASH (BCRYPT, LA SAL VA DENTRO DEL HASH) ===<br>";
$inicio = hrtime(true);
$bcrypt1 = password_hash($claveUsuario1, PASSWORD_BCRYPT, ['cost' => 12]);
$tiempoBcrypt = (hrtime(true) - $inicio) / 1000;
$bcrypt2 = password_hash($claveUsuario2, PASSWORD_BCRYPT, ['cost' => 12]);

echo "Hash Usuario 1: $bcrypt1 <br>";
echo "Hash Usuario 2: $bcrypt2 <br>";
echo "¿Son idénticos? " . ($bcrypt1 === $bcrypt2 ? "SÍ" : "NO") . "<br>";
echo "password_verify con la clave correcta: " . (password_verify("manizales2026", $bcrypt1) ? "true" : "false") . "<br>";
echo "password_verify con una clave equivocada: " . (password_verify("manizales2025", $bcrypt1) ? "true" : "false") . "<br><br>";

echo "=== VELOCIDAD ===<br>";
echo "sha256 con sal: " . round($tiempoSha, 1) . " microsegundos<br>";
echo "password_hash con costo 12: " . round($tiempoBcrypt / 1000, 1) . " milisegundos<br>";
?>
