<?php
$metodo = "AES-256-CBC";

$claveDelProfe = "ClaveSecretaDe32CaracteresExact";
$clave = "NegocioSeguro2026ManizalesPablo!";

echo "Largo de la clave del codigo base: " . strlen($claveDelProfe) . " caracteres<br>";
echo "Largo de la clave que use: " . strlen($clave) . " caracteres<br><br>";

$iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($metodo));

$mensaje_original = "Pedido 1087 de pablo_nieto, tarjeta terminada en 4417, envio a Calle 23 # 21-40 Manizales";

$inicio = hrtime(true);
$texto_cifrado = openssl_encrypt($mensaje_original, $metodo, $clave, 0, $iv);
$tiempoCifrar = (hrtime(true) - $inicio) / 1000;

echo "Mensaje original: $mensaje_original <br>";
echo "IV (en hexadecimal): " . bin2hex($iv) . "<br>";
echo "Mensaje cifrado (en base64): $texto_cifrado <br><br>";

$inicio = hrtime(true);
$texto_descifrado = openssl_decrypt($texto_cifrado, $metodo, $clave, 0, $iv);
$tiempoDescifrar = (hrtime(true) - $inicio) / 1000;

echo "Mensaje descifrado: $texto_descifrado <br>";
echo "¿El descifrado es igual al original? " . ($texto_descifrado === $mensaje_original ? "SÍ" : "NO") . "<br>";
echo "Tiempo para cifrar: " . round($tiempoCifrar, 1) . " microsegundos, para descifrar: " . round($tiempoDescifrar, 1) . " microsegundos<br><br>";

$otroIv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($metodo));
echo "=== EL MISMO MENSAJE CON OTRO IV ===<br>";
echo "Cifrado con otro IV: " . openssl_encrypt($mensaje_original, $metodo, $clave, 0, $otroIv) . "<br><br>";

echo "=== DESCIFRAR CON UNA CLAVE EQUIVOCADA ===<br>";
$claveEquivocada = "OtraClaveQueNoEsLaDelEquipo12345";
$intento = openssl_decrypt($texto_cifrado, $metodo, $claveEquivocada, 0, $iv);
echo "Resultado: " . ($intento === false ? "falla, no se recupera el mensaje" : $intento) . "<br>";
?>
